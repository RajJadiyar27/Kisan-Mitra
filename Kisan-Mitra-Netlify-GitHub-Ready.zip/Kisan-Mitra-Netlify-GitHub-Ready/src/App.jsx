import { useState } from "react";
import {
  LayoutDashboard,
  Sprout,
  TrendingUp,
  Bot,
  LogOut,
  Thermometer,
  CloudRain,
  Droplets,
  MapPin,
  ArrowUpRight,
  ArrowDownRight,
  Search,
  Menu,
  X,
} from "lucide-react";
import "./App.css";

const data = {
  user: { name: "Raj", location: "Mumbai, Maharashtra" },
  weather: { temperature: 29.5, rainfall: 0, humidity: 71, rainProbability: 67, wind: 3 },
  crops: [
    { id: 1, name: "Wheat", variety: "Lokwan", area: 2.5, stage: "Flowering", health: "Good" },
    { id: 2, name: "Onion", variety: "N-53", area: 1.5, stage: "Bulb Formation", health: "Good" },
    { id: 3, name: "Tomato", variety: "Hybrid", area: 1, stage: "Fruit Development", health: "Needs Attention" },
  ],
  markets: [
    { mandi: "Lasalgaon", crop: "Wheat", price: 2450, change: 3.2, forecast: 2613, verdict: "BUY" },
    { mandi: "Pune", crop: "Wheat", price: 2520, change: 2.8, forecast: 2650, verdict: "BUY" },
    { mandi: "Nagpur", crop: "Wheat", price: 2480, change: 1.9, forecast: 2580, verdict: "HOLD" },
    { mandi: "Akola", crop: "Wheat", price: 2420, change: 1.2, forecast: 2500, verdict: "HOLD" },
    { mandi: "Nashik", crop: "Wheat", price: 2490, change: 2.1, forecast: 2575, verdict: "BUY" },
    { mandi: "Ahmednagar", crop: "Wheat", price: 2460, change: 1.6, forecast: 2535, verdict: "HOLD" },
    { mandi: "Lasalgaon", crop: "Onion", price: 2800, change: -1.4, forecast: 2750, verdict: "SELL" },
    { mandi: "Pune", crop: "Onion", price: 2920, change: 0.8, forecast: 2980, verdict: "HOLD" },
    { mandi: "Nashik", crop: "Onion", price: 2860, change: -0.5, forecast: 2840, verdict: "HOLD" },
  ],
};

const wheatTrend = [2310, 2350, 2380, 2410, 2395, 2430, 2450];
const onionTrend = [2910, 2870, 2890, 2850, 2830, 2815, 2800];

function App() {
  const [page, setPage] = useState("dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);

  const navigate = (next) => {
    setPage(next);
    setMobileOpen(false);
  };

  const activeLabel = {
    dashboard: "Dashboard",
    crops: "My Crops",
    market: "Market Intelligence",
    advisory: "AI Advisory",
  }[page];

  return (
    <div className="app-shell">
      <header className="mobile-topbar">
        <div className="brand"><span className="brand-mark"><Sprout size={21} /></span> Kisan Mitra</div>
        <button className="icon-button" onClick={() => setMobileOpen(v => !v)}>{mobileOpen ? <X /> : <Menu />}</button>
      </header>

      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <div className="brand sidebar-brand"><span className="brand-mark"><Sprout size={21} /></span> Kisan Mitra</div>
        <nav>
          <NavItem active={page === "dashboard"} label="Dashboard" icon={<LayoutDashboard size={19} />} onClick={() => navigate("dashboard")} />
          <NavItem active={page === "crops"} label="My Crops" icon={<Sprout size={19} />} onClick={() => navigate("crops")} />
          <NavItem active={page === "market"} label="Market" icon={<TrendingUp size={19} />} onClick={() => navigate("market")} />
          <NavItem active={page === "advisory"} label="AI Advisory" icon={<Bot size={19} />} onClick={() => navigate("advisory")} />
        </nav>
        <button className="logout-button"><LogOut size={19} /> Logout</button>
      </aside>

      <main className="main-content">
        <div className="topbar"><div className="crumb">Kisan Mitra <span>/</span> {activeLabel}</div><div className="demo-pill">DEMO DATA</div></div>
        {page === "dashboard" && <Dashboard onNavigate={navigate} />}
        {page === "crops" && <CropsPage />}
        {page === "market" && <MarketPage />}
        {page === "advisory" && <AdvisoryPage />}
      </main>
    </div>
  );
}

function NavItem({ active, label, icon, onClick }) {
  return <button className={`nav-item ${active ? "active" : ""}`} onClick={onClick}>{icon}<span>{label}</span></button>;
}

function Header({ eyebrow, title, subtitle, right }) {
  return <header className="page-header"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{right}</header>;
}

function Stat({ icon, label, value, detail }) {
  return <div className="stat-card"><div className="stat-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong>{detail && <small>{detail}</small>}</div></div>;
}

function Dashboard({ onNavigate }) {
  const m = data.markets[0];
  const c = data.crops;
  return <>
    <Header eyebrow="Farmer Dashboard" title={`Namaste, ${data.user.name} 👋`} subtitle="Your agriculture overview for today." right={<div className="location-chip"><MapPin size={15}/> {data.user.location}</div>} />
    <section className="stats-grid">
      <Stat icon={<Thermometer />} label="Temperature" value={`${data.weather.temperature}°C`} detail={`Humidity ${data.weather.humidity}%`} />
      <Stat icon={<CloudRain />} label="Rainfall" value={`${data.weather.rainfall} mm`} detail={`${data.weather.rainProbability}% rain probability`} />
      <Stat icon={<TrendingUp />} label="Wheat price" value={`₹${m.price}`} detail={`${m.change > 0 ? "+" : ""}${m.change}% today`} />
      <Stat icon={<Sprout />} label="My crops" value={c.length} detail={`${c.reduce((s, x) => s + x.area, 0)} acres registered`} />
    </section>

    <section className="two-column">
      <div className="card feature-card">
        <div className="card-top"><div><div className="section-label">MARKET INTELLIGENCE</div><h2>AI Market Signal</h2></div><span className={`badge ${m.verdict.toLowerCase()}`}>{m.verdict}</span></div>
        <div className="hero-price"><span>₹{m.forecast}</span><small>/quintal estimated target</small></div>
        <p className="muted">Sample forecast for {m.crop.toLowerCase()} at {m.mandi} mandi.</p>
        <div className="mini-stats"><div><span>Current</span><b>₹{m.price}</b></div><div><span>Change</span><b className={m.change >= 0 ? "positive" : "negative"}>{m.change >= 0 ? "+" : ""}{m.change}%</b></div><div><span>Mandi</span><b>{m.mandi}</b></div></div>
        <button className="link-button" onClick={() => onNavigate("market")}>View market analysis <ArrowUpRight size={16}/></button>
      </div>
      <div className="card feature-card advisory-feature">
        <div className="ai-icon"><Bot size={25}/></div><div className="section-label">TODAY'S ADVISORY</div><h2>Plan farm activities with better timing.</h2>
        <p className="muted">Check soil moisture before irrigation and review weather conditions before spraying or harvesting.</p>
        <div className="check-list"><div><span>✓</span> Check soil moisture</div><div><span>✓</span> Monitor rainfall probability</div><div><span>✓</span> Inspect crops for stress</div></div>
        <button className="link-button" onClick={() => onNavigate("advisory")}>Ask AI Kisan Mitra <ArrowUpRight size={16}/></button>
      </div>
    </section>

    <section className="card weather-card"><div className="section-row"><div><div className="section-label">WEATHER</div><h2>Today's conditions</h2></div><span className="location-chip"><MapPin size={14}/> Mumbai</span></div><div className="weather-grid"><Weather label="Temperature" value={`${data.weather.temperature}°C`} icon={<Thermometer/>}/><Weather label="Humidity" value={`${data.weather.humidity}%`} icon={<Droplets/>}/><Weather label="Rain probability" value={`${data.weather.rainProbability}%`} icon={<CloudRain/>}/><Weather label="Wind" value={`${data.weather.wind} km/h`} icon={<TrendingUp/>}/></div></section>

    <section className="card crop-strip"><div className="section-row"><div><div className="section-label">MY FARM</div><h2>Crop portfolio</h2></div><button className="outline-button" onClick={() => onNavigate("crops")}>View all</button></div><div className="crop-row-grid">{c.slice(0, 3).map(crop => <div className="crop-row" key={crop.id}><div className="crop-avatar"><Sprout size={20}/></div><div><b>{crop.name}</b><span>{crop.area} acres · {crop.stage}</span></div><small className={crop.health === "Good" ? "status good" : "status warn"}>{crop.health}</small></div>)}</div></section>
  </>;
}

function Weather({ label, value, icon }) { return <div className="weather-stat"><div className="tiny-icon">{icon}</div><div><span>{label}</span><b>{value}</b></div></div>; }

function CropsPage() {
  return <><Header eyebrow="My Farm" title="My Crops" subtitle="Track your crops, growth stage and crop health." right={<button className="primary-button">+ Add Crop</button>} /><div className="crop-page-grid">{data.crops.map(crop => <div className="card crop-card" key={crop.id}><div className="crop-card-top"><div className="large-crop-icon"><Sprout size={28}/></div><small className={crop.health === "Good" ? "status good" : "status warn"}>{crop.health}</small></div><h2>{crop.name}</h2><p>{crop.variety}</p><div className="crop-detail-grid"><div><span>Area</span><b>{crop.area} acres</b></div><div><span>Growth stage</span><b>{crop.stage}</b></div></div><button className="outline-button">View crop details <ArrowUpRight size={16}/></button></div>)}</div></>;
}

function MarketPage() {
  const [crop, setCrop] = useState("Wheat");
  const [mandi, setMandi] = useState("Lasalgaon");
  const record = data.markets.find(m => m.crop === crop && m.mandi === mandi) || data.markets.find(m => m.crop === crop);
  const trend = crop === "Wheat" ? wheatTrend : onionTrend;
  const mandis = data.markets.filter(m => m.crop === crop).map(m => m.mandi);
  return <>
    <Header eyebrow="Market Intelligence" title="Market Prices & Forecast" subtitle="Sample mandi prices, recent trend and estimated target." />
    <div className="filter-bar"><div className="field-label">Crop</div><select value={crop} onChange={e => { setCrop(e.target.value); setMandi(e.target.value === "Wheat" ? "Lasalgaon" : "Lasalgaon"); }}>{["Wheat", "Onion"].map(x => <option key={x}>{x}</option>)}</select><div className="field-label">Mandi</div><select value={mandi} onChange={e => setMandi(e.target.value)}>{mandis.map(x => <option key={x}>{x}</option>)}</select><div className="demo-note">Sample market data</div></div>
    <section className="market-grid"><div className="card market-main"><div className="card-top"><div><div className="section-label">{record.mandi.toUpperCase()} MANDI</div><h2>{record.crop}</h2></div><span className={`badge ${record.verdict.toLowerCase()}`}>{record.verdict}</span></div><div className="huge-price">₹{record.price}<small>/quintal</small></div><div className={record.change >= 0 ? "positive trend-value" : "negative trend-value"}>{record.change >= 0 ? <ArrowUpRight size={18}/> : <ArrowDownRight size={18}/>} {Math.abs(record.change)}% today</div><div className="bars">{trend.map((p, i) => <div className="bar-col" key={`${p}-${i}`}><div className="bar" style={{height: `${40 + ((p - Math.min(...trend))/(Math.max(...trend)-Math.min(...trend)||1))*130}px`}}></div><span>{20+i+1}</span></div>)}</div></div><div className="card target-card"><div className="section-label">ESTIMATED TARGET</div><div className="target-price">₹{record.forecast}</div><p className="muted">Projected near-term price from the sample trend model.</p><div className="target-box"><span>Signal</span><b>{record.verdict}</b><small>Monitor the market before selling.</small></div></div></section>
    <section className="card table-card"><div className="section-row"><div><div className="section-label">MANDI COMPARISON</div><h2>{crop} across markets</h2></div><Search size={19}/></div><div className="table-scroll"><table><thead><tr><th>Mandi</th><th>Current Price</th><th>Change</th><th>Forecast</th><th>Signal</th></tr></thead><tbody>{data.markets.filter(m => m.crop === crop).map(m => <tr key={`${m.crop}-${m.mandi}`}><td><b>{m.mandi}</b></td><td>₹{m.price}</td><td className={m.change >= 0 ? "positive" : "negative"}>{m.change >= 0 ? "+" : ""}{m.change}%</td><td>₹{m.forecast}</td><td><span className={`badge ${m.verdict.toLowerCase()}`}>{m.verdict}</span></td></tr>)}</tbody></table></div></section>
  </>;
}

function AdvisoryPage() {
  const recommendations = [
    { icon: <Droplets/>, title: "Irrigation", text: "Check soil moisture before watering. Avoid unnecessary irrigation if the root zone is already moist." },
    { icon: <CloudRain/>, title: "Weather window", text: "Review rainfall probability before spraying or harvesting and avoid unsuitable conditions." },
    { icon: <Sprout/>, title: "Crop inspection", text: "Inspect leaves, stems and soil for early signs of stress before taking corrective action." },
  ];
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const ask = () => { if (!question.trim()) return; setAnswer("Based on the current sample conditions, check soil moisture first, monitor rainfall and avoid unnecessary irrigation. Review weather before spraying or harvesting."); };
  return <><Header eyebrow="AI Kisan Mitra" title="AI Advisory" subtitle="Simple farming recommendations using the project's sample farm conditions." /><div className="advisory-grid">{recommendations.map(r => <div className="card recommendation" key={r.title}><div className="large-crop-icon">{r.icon}</div><div className="section-label">RECOMMENDATION</div><h2>{r.title}</h2><p className="muted">{r.text}</p><span className="recommendation-tag">Demo recommendation</span></div>)}</div><section className="card assistant"><div className="assistant-header"><div className="ai-icon"><Bot size={26}/></div><div><div className="section-label">KISAN MITRA AI</div><h2>Ask your farming assistant</h2></div></div><textarea value={question} onChange={e => setQuestion(e.target.value)} placeholder="Example: Should I irrigate my wheat crop today?"/><button className="primary-button" onClick={ask}>Ask Kisan Mitra <Bot size={17}/></button>{answer && <div className="answer"><b>Kisan Mitra says</b><p>{answer}</p></div>}</section></>;
}

export default App;
