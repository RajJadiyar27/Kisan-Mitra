# Kisan Mitra

Sample-data-only React/Vite agriculture dashboard.

## Features
- Dashboard
- My Crops
- Market Intelligence
- AI Advisory
- Responsive layout
- No external API keys required

## Run locally
```bash
npm install
npm run dev
```

## Build for deployment
```bash
npm run build
```

Build output: `dist`
